﻿using System;
using SQLite;

namespace Lab17Mercado
{
    public class Book
    {
        [PrimaryKey, AutoIncrement]
            public int BookId { get; set; }

        public string BookTitle { get; set; }

        public string ISBN { get; set; }

        public Book()
        {
        }
    }
}
