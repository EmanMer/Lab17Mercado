﻿using Android.App;
using Android.Widget;
using Android.OS;
using SQLite;
using System.IO;

namespace Lab17Mercado
{
    [Activity(Label = "Book Inventory", MainLauncher = true, Icon = "@mipmap/book_icon")]
    public class MainActivity : Activity
    {
        EditText txtISBN;
        EditText txtBookTitle;
        Button btnAddBook;
        ListView tblBooks;

        string filePath = Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments), "BookList.db3");

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);

            txtISBN = FindViewById<EditText>(Resource.Id.txtISBN);
            txtBookTitle = FindViewById<EditText>(Resource.Id.txtTitle);
            btnAddBook = FindViewById<Button>(Resource.Id.btnAddBook);
            tblBooks = FindViewById<ListView>(Resource.Id.tblBooks);

            btnAddBook.Click += BtnAddBook_Click;

            //TODO: Add DB Creation
            // create the database file if it doesn't exist
            try
            {
                // Create our connection, if the database and/or table doesn't exist create it
                var db = new SQLiteConnection(filePath);
                db.CreateTable<Book>();
            }
            catch (IOException ex)
            {
                var reason = string.Format("Failed to create Table - reason { 0}", ex.Message);
                 Toast.MakeText(this, reason, ToastLength.Long).Show();
            }
        }

        void BtnAddBook_Click(object sender, System.EventArgs e)
        {
            string alertTitle, alertMessage;
            if (!string.IsNullOrEmpty(txtBookTitle.Text))
            {
                var newBook = new Book { BookTitle = txtBookTitle.Text, ISBN = txtISBN.Text };

                var db = new SQLiteConnection(filePath);
                db.Insert(newBook);

                alertTitle = "Success!";
                alertMessage = "Book added succesfully!";
            }
            else
            {
                alertTitle = "Failed to add book.";
                alertMessage = "Enter valid book title.";
            }

            AlertDialog.Builder alert = new AlertDialog.Builder(this);

            alert.SetTitle(alertTitle);
            alert.SetMessage(alertMessage);
            alert.SetPositiveButton("OK", (senderAlert, args) =>
            {
            Toast.MakeText(this, "Continue!", ToastLength.Short).Show();});
        }

    }
}

